Component({
  properties: {
    start: { type: String, value: '2025-10-10T00:00:00+08:00' }
  },
  data: { days: 0, hours: '00', mins: '00', secs: '00' },
  lifetimes: {
    attached: function () {
      var self = this;
      var raw = String(this.data.start || '2025-10-10T00:00:00+08:00')
        .replace(/-/g, '/').replace('T', ' ').replace('+08:00', '').replace('Z', '').trim();
      this._start = new Date(raw).getTime();
      if (isNaN(this._start)) this._start = new Date(2025, 9, 10, 0, 0, 0).getTime();
      this._timer = setInterval(function () { self.tick(); }, 1000);
      this.tick();
    },
    detached: function () {
      if (this._timer) clearInterval(this._timer);
      this._timer = null;
    }
  },
  methods: {
    pad: function (n) { return n < 10 ? '0' + n : '' + n; },
    tick: function () {
      var diff = Date.now() - this._start;
      if (diff < 0) diff = 0;
      var days = Math.floor(diff / 86400000);
      var hours = Math.floor(diff % 86400000 / 3600000);
      var mins = Math.floor(diff % 3600000 / 60000);
      var secs = Math.floor(diff % 60000 / 1000);
      this.setData({
        days: days,
        hours: this.pad(hours),
        mins: this.pad(mins),
        secs: this.pad(secs)
      });
    }
  }
});
