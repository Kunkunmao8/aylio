var scenes = [
  {
    date: '10.10', season: '初夏', title: '第一次直播',
    desc: '刚因为《双程》认识，一个坐得笔直，一个紧张到接不上话，环球梦之旅从这里开始。',
    img: '/images/extra/z12.jpg.jpg'
  },
  {
    date: '08.19', season: '盛夏', title: '七夕留念',
    desc: '把喜欢放进同一张照片里，热闹是世界的，安静是我们的。',
    img: '/images/extra/z11.jpg.jpg'
  },
  {
    date: '09.01', season: '夏末', title: '海底套房的一晚',
    desc: '蓝色玻璃外面是鱼群，玻璃里面是两个慢慢靠近的人。',
    img: '/images/extra/home-banner1.jpg.jpg'
  },
  {
    date: '10.10', season: '深秋', title: '相识一周年',
    desc: '蛋糕上的烛光摇了一下，日子就这样被稳稳地接住。',
    img: '/images/extra/feature-banner13.jpg.jpg'
  },
  {
    date: '11.08', season: '初冬', title: '初雪时刻',
    desc: '第一场雪落下来的时候，我们刚好站在一起。',
    img: '/images/extra/z1.jpg.jpg'
  }
];

Page({
  data: {
    scenes: scenes,
    current: 0,
    scene: scenes[0],
    auto: false
  },
  onLoad: function () {
    this.setData({ scene: scenes[0] });
  },
  onShow: function () { if (this.data.auto) this.startAuto(); },
  onHide: function () { this.stopAuto(); },
  onUnload: function () { this.stopAuto(); },
  go: function (e) {
    var i = Number(e.currentTarget.dataset.i);
    if (isNaN(i) || !scenes[i]) return;
    this.setData({ current: i, scene: scenes[i] });
    this.restartAuto();
  },
  prev: function () {
    var i = (this.data.current + scenes.length - 1) % scenes.length;
    this.setData({ current: i, scene: scenes[i] });
    this.restartAuto();
  },
  next: function () {
    var i = (this.data.current + 1) % scenes.length;
    this.setData({ current: i, scene: scenes[i] });
    this.restartAuto();
  },
  toggleAuto: function () {
    if (this.data.auto) {
      this.stopAuto();
      this.setData({ auto: false });
    } else {
      this.startAuto();
      this.setData({ auto: true });
    }
  },
  startAuto: function () {
    var self = this;
    this.stopAuto();
    this._autoTimer = setInterval(function () {
      var i = (self.data.current + 1) % scenes.length;
      self.setData({ current: i, scene: scenes[i] });
    }, 6000);
  },
  stopAuto: function () {
    if (this._autoTimer) clearInterval(this._autoTimer);
    this._autoTimer = null;
  },
  restartAuto: function () {
    if (this.data.auto) this.startAuto();
  }
});
