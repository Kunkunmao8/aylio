# 政瞳之家 · 小程序扩展包

这个包里是网站刚加的三块内容对应的小程序页面：

- `components/love-timer`：首页相识天数计时器（从 2025.10.10 起算）
- `pages/theater`：时光放映厅，5 幕、时间轴、上一幕/自动放映/下一幕
- `pages/cardgame`：翻牌游戏，9 对照片、18 张牌、5 秒预览、步数、重新洗牌
- `images/extra`：页面用到的照片已经打包在本地，不依赖图片域名白名单

## 接入方式

在电脑上打开微信开发者工具的项目目录，确认根目录有 `app.json`，然后执行：

```bash
python install_extra.py --project "你的小程序项目目录"
```

例如：

```bash
python install_extra.py --project "C:\Users\Linji\WeChatProjects\miniprogram-1"
```

脚本会自动做这些事：

1. 把页面、组件、图片复制进项目；
2. 在 `app.json` 的 `pages` 里注册 `pages/theater/index`、`pages/cardgame/index`；
3. 在首页 `pages/home/index.json` 注册 `love-timer` 组件；
4. 在首页 `hero` 下面插入 `<love-timer />`；
5. 在首页底部加上「时光放映厅 / 翻牌游戏」两个入口；
6. 在 `app.wxss` 追加入口样式。

## 如果脚本找不到首页位置

不同版本首页结构可能不同。脚本会优先找 `class="hero"`，找不到再找 `class="pg-head"`，都没有就放在最前面。打开 `pages/home/index.wxml` 确认 `<love-timer />` 是否在首页顶部；如果没有，手动放到 hero 图下面即可。

## 注意

- 页面图片使用包内的 `/images/extra/...`，不需要配置 `downloadFile` 合法域名。
- 如果项目开了自定义 tabBar，需要把两个新页面再加到 tabBar 的 `list` 里，或保留首页底部的入口按钮。
- 这个包不会覆盖你现有的首页内容和样式，只做追加。
