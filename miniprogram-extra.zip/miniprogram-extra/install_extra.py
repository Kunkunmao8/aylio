#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把「相识计时器 / 时光放映厅 / 翻牌游戏」接进现有微信小程序。
用法：
  python install_extra.py --project C:\\Users\\Linji\\WeChatProjects\\miniprogram-1
不传 --project 时，会尝试常见路径和当前目录。
"""
import argparse
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

def find_project(explicit):
    if explicit:
        return os.path.abspath(explicit)
    candidates = [
        os.getcwd(),
        os.path.expanduser('~/WeChatProjects/miniprogram-1'),
        r'C:\Users\Linji\WeChatProjects\miniprogram-1',
        r'C:\Users\Linji\Doubao\chats\2026-11-20\new-chat\miniprogram',
    ]
    for c in candidates:
        if c and os.path.isfile(os.path.join(c, 'app.json')):
            return c
    return None

def load_json(path, default=None):
    if not os.path.exists(path):
        return default
    with open(path, 'r', encoding='utf-8-sig') as f:
        return json.load(f)

def save_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')

def copy_extra(project):
    for name in ('components/love-timer', 'pages/theater', 'pages/cardgame', 'images/extra'):
        src = os.path.join(HERE, name)
        dst = os.path.join(project, name)
        if not os.path.isdir(dst):
            os.makedirs(dst, exist_ok=True)
        for f in os.listdir(src):
            shutil.copy2(os.path.join(src, f), os.path.join(dst, f))
        print('  copied', name)

def patch_app_json(project):
    path = os.path.join(project, 'app.json')
    data = load_json(path)
    if not data or 'pages' not in data:
        raise RuntimeError('app.json 里没有 pages 列表，无法自动注册页面')
    pages = data['pages']
    before = list(pages)

    new_pages = ['pages/theater/index', 'pages/cardgame/index']
    for p in new_pages:
        if p in pages:
            pages.remove(p)

    insert_at = len(pages)
    for i, p in enumerate(pages):
        if p in ('pages/contact/index', 'pages/contact/contact', 'pages/contact'):
            insert_at = i
            break
    pages[insert_at:insert_at] = new_pages
    if pages != before:
        save_json(path, data)
        print('  app.json pages ->', ' / '.join(new_pages), '已插入')

def ensure_home_component(project):
    home_dir = os.path.join(project, 'pages', 'home')
    page_json = os.path.join(home_dir, 'index.json')
    if not os.path.isfile(page_json):
        print('  ! 没有 pages/home/index.json，跳过首页组件注册')
        return False
    data = load_json(page_json, {})
    using = data.get('usingComponents') or {}
    using['love-timer'] = '/components/love-timer/index'
    data['usingComponents'] = using
    save_json(page_json, data)
    print('  pages/home/index.json -> love-timer 已注册')
    return True

def patch_home_wxml(project):
    wxml = os.path.join(project, 'pages', 'home', 'index.wxml')
    if not os.path.isfile(wxml):
        print('  ! 没有 pages/home/index.wxml，跳过首页插入')
        return
    with open(wxml, 'r', encoding='utf-8') as f:
        text = f.read()
    changed = False

    if '<love-timer' not in text:
        m = re.search(r'<view\b[^>]*class="(?:[^"]*\bhero\b[^"]*)"[^>]*>[\s\S]*?</view>', text)
        if m:
            insert_at = m.end()
            text = text[:insert_at] + '\n\n<love-timer />\n' + text[insert_at:]
            changed = True
        else:
            m2 = re.search(r'<view\b[^>]*class="(?:[^"]*\bpg-head\b[^"]*)"[^>]*>[\s\S]*?</view>', text)
            if m2:
                insert_at = m2.end()
                text = text[:insert_at] + '\n\n<love-timer />\n' + text[insert_at:]
                changed = True
            else:
                text = '<love-timer />\n' + text
                changed = True
        print('  首页顶部已插入 <love-timer />')

    if '<!-- love-extra-entry -->' not in text:
        block = '''\n<!-- love-extra-entry -->\n<view class="extra-entry">\n  <view class="extra-title">番外</view>\n  <view class="extra-row">\n    <navigator class="extra-btn" url="/pages/theater/index">时光放映厅</navigator>\n    <navigator class="extra-btn" url="/pages/cardgame/index">翻牌游戏</navigator>\n  </view>\n</view>\n'''
        pos = text.rfind('</view>')
        if pos != -1:
            text = text[:pos] + block + text[pos:]
        else:
            text += block
        changed = True
        print('  首页底部已加入「时光放映厅 / 翻牌游戏」入口')

    if changed:
        with open(wxml, 'w', encoding='utf-8') as f:
            f.write(text)

def append_global_css(project):
    wxss = os.path.join(project, 'app.wxss')
    marker = '/* love-extra-entry */'
    style = '''
/* love-extra-entry */
.extra-entry { margin: 34rpx 24rpx 52rpx; padding: 28rpx; background: #FBF3E7; border: 1rpx solid #EADAC6; border-radius: 28rpx; box-sizing: border-box; }
.extra-title { font-size: 25rpx; color: #8A776D; letter-spacing: 4rpx; margin-bottom: 18rpx; }
.extra-row { display: flex; justify-content: space-between; }
.extra-btn + .extra-btn { margin-left: 16rpx; }
.extra-btn { flex: 1; text-align: center; padding: 22rpx 8rpx; border-radius: 40rpx; background: #C65F33; color: #FFF8EC; font-size: 26rpx; text-decoration: none; }
'''
    existing = ''
    if os.path.isfile(wxss):
        with open(wxss, 'r', encoding='utf-8') as f:
            existing = f.read()
    if marker not in existing:
        with open(wxss, 'a', encoding='utf-8') as f:
            f.write(style)
        print('  app.wxss -> 入口样式已追加')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project', help='小程序项目根目录（含 app.json）')
    args = ap.parse_args()
    project = find_project(args.project)
    if not project or not os.path.isfile(os.path.join(project, 'app.json')):
        print('找不到小程序项目。请用 --project 指定含 app.json 的目录。')
        sys.exit(2)
    print('项目：', project)
    copy_extra(project)
    patch_app_json(project)
    ensure_home_component(project)
    patch_home_wxml(project)
    append_global_css(project)
    print('完成。打开微信开发者工具刷新即可；若首页没有显示计时器，请检查 pages/home/index.wxml 是否包含 hero。')

if __name__ == '__main__':
    main()
