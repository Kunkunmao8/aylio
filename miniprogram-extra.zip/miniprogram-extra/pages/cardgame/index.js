var POOL = [
  '/images/extra/z12.jpg.jpg',
  '/images/extra/z11.jpg.jpg',
  '/images/extra/v11-2.jpg.jpg',
  '/images/extra/home-banner1.jpg.jpg',
  '/images/extra/menu-banner12.jpg.jpg',
  '/images/extra/feature-banner13.jpg.jpg',
  '/images/extra/contact-banner11.jpg.jpg',
  '/images/extra/z1.jpg.jpg',
  '/images/extra/z2.jpg.jpg'
];

Page({
  data: {
    cards: [],
    moves: 0,
    matchedCount: 0,
    previewing: true,
    count: 5,
    celebrating: false,
    confetti: []
  },
  onLoad: function () { this.build(); },
  onUnload: function () {
    if (this._previewTimer) clearTimeout(this._previewTimer);
    if (this._flipTimer) clearTimeout(this._flipTimer);
    if (this._celebrateTimer) clearTimeout(this._celebrateTimer);
  },
  build: function () {
    if (this._celebrateTimer) clearTimeout(this._celebrateTimer);
    var deck = [];
    for (var i = 0; i < POOL.length; i++) {
      deck.push({ key: i + '-a', pair: i, img: POOL[i], flipped: true, matched: false });
      deck.push({ key: i + '-b', pair: i, img: POOL[i], flipped: true, matched: false });
    }
    for (var j = deck.length - 1; j > 0; j--) {
      var k = Math.floor(Math.random() * (j + 1));
      var tmp = deck[j]; deck[j] = deck[k]; deck[k] = tmp;
    }
    this._first = -1;
    this._lock = true;
    this.setData({ cards: deck, moves: 0, matchedCount: 0, previewing: true, count: 5, celebrating: false, confetti: [] });
    this.startPreview();
  },
  startPreview: function () {
    var self = this;
    if (this._previewTimer) clearTimeout(this._previewTimer);
    if (this._countTimer) clearInterval(this._countTimer);
    var n = 5;
    this._countTimer = setInterval(function () {
      n--;
      if (n <= 0) {
        clearInterval(self._countTimer);
        self.setData({ count: 0 });
      } else {
        self.setData({ count: n });
      }
    }, 1000);
    this._previewTimer = setTimeout(function () {
      clearInterval(self._countTimer);
      var cards = self.data.cards.map(function (c) {
        return { key: c.key, pair: c.pair, img: c.img, flipped: false, matched: false };
      });
      self._lock = false;
      self._first = -1;
      self.setData({ cards: cards, previewing: false, count: 0 });
    }, 5000);
  },
  flip: function (e) {
    var i = Number(e.currentTarget.dataset.i);
    var card = this.data.cards[i];
    if (!card || this._lock || card.flipped || card.matched) return;

    var key = 'cards[' + i + '].flipped';
    var patch = {}; patch[key] = true;
    this.setData(patch);

    if (this._first < 0) {
      this._first = i;
      return;
    }

    var first = this.data.cards[this._first];
    var self = this;
    if (first.pair === card.pair && this._first !== i) {
      var a = 'cards[' + this._first + '].matched';
      var b = 'cards[' + i + '].matched';
      var newCount = this.data.matchedCount + 1;
      var p = {};
      p[a] = true;
      p[b] = true;
      p.matchedCount = newCount;
      p.moves = this.data.moves + 1;
      this._first = -1;
      this.setData(p);
      if (newCount === 9) {
        this._celebrateTimer = setTimeout(function () { self.celebrate(); }, 450);
      }
    } else {
      this._lock = true;
      var idx1 = this._first;
      this._first = -1;
      this.setData({ moves: this.data.moves + 1 });
      this._flipTimer = setTimeout(function () {
        var p2 = {};
        p2['cards[' + idx1 + '].flipped'] = false;
        p2['cards[' + i + '].flipped'] = false;
        self._lock = false;
        self.setData(p2);
      }, 700);
    }
  },
  celebrate: function () {
    var colors = ['#BF5B2E', '#D07C48', '#F3D79A', '#FFF9F3', '#A65A33', '#E8B4A0'];
    var pieces = [];
    for (var i = 0; i < 52; i++) {
      pieces.push({
        id: i,
        left: (Math.random() * 100).toFixed(1),
        color: colors[i % colors.length],
        dir: i % 6,
        delay: Math.floor(Math.random() * 1000),
        duration: 1800 + Math.floor(Math.random() * 1800)
      });
    }
    this.setData({ celebrating: true, confetti: pieces });
    if (wx.vibrateShort) { try { wx.vibrateShort({ type: 'light' }); } catch (e) {} }
  },
  closeCelebration: function () {
    this.setData({ celebrating: false, confetti: [] });
  },
  replay: function () {
    if (this._celebrateTimer) clearTimeout(this._celebrateTimer);
    this.setData({ celebrating: false, confetti: [] });
    this.build();
  },
  noop: function () {},
  restart: function () {
    if (this._flipTimer) clearTimeout(this._flipTimer);
    if (this._previewTimer) clearTimeout(this._previewTimer);
    if (this._countTimer) clearInterval(this._countTimer);
    if (this._celebrateTimer) clearTimeout(this._celebrateTimer);
    this._first = -1;
    this._lock = true;
    this.setData({ celebrating: false, confetti: [] });
    this.build();
  }
});
